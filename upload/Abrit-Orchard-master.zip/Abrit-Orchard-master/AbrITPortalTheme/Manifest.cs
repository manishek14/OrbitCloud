using OrchardCore.DisplayManagement.Manifest;

[assembly: Theme(
    Name = "AbrITPortalTheme",
    Author = "The Orchard Core Team",
    Website = "https://orchardcore.net",
    Version = "0.0.1",
    Description = "AbrITPortalTheme"
)]
